"""
1. Write a python program to implement List-to-Series Conversion

"""


import pandas as pd

names = ['a','b','c']
x = pd.Series(names)
print(names)
