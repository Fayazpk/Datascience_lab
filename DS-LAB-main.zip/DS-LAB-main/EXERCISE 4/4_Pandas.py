"""
4. Given a 2D List, convert it into corresponding dataframe and display it.

"""


import pandas as pd

details = [[1,2],[3,4]]
  
df = pd.DataFrame(details)
  
print(df)
