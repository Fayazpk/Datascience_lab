import numpy as np

x = np.arange(start=30, stop=71, step=2)
x = np.arange(30,71,2)
print(x)
