import numpy as np

x = np.identity(3)
print(x)

